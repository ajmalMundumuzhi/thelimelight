module.exports={
    PRODUCT_COLLECTION:'product',
    USER_COLLECTION:'admin',
    CART_COLLECTION:'cart'
}

// 19:30
// 4-44